# Event-Planner-PHP-Project

Event Management System" is a web-based project. This system organizes the event for the customers. This system is built with PHP, MySQL, HTML, and CSS using the Bootstrap Framework.

## Download Project

Download a project from github 

[Download Project](https://github.com/ganeshkavhar/Event-Planner-PHP-Project/)


## Import 

after download extract to Xampp folder under htdocs with any name for ex Event 

## Import Database

Open Localhost/phpmyadmin/ in browser and create new database with year2project name thn import database file year2project.sql


## Run Project

Lets open the Browser and type Localhost/Event/


![Screenshot 2020-12-17 at 5 24 10 AM](https://user-images.githubusercontent.com/20369800/102421370-4ed02500-402a-11eb-8e68-96aab7a9b783.png)



# Developer 

[ganesh kavhar](https://about.me/ganeshkavhar) ,<br />
Pune, Maharashtra, India.<br />


# Donation

If you have found my softwares to be of any use to you, do consider helping me pay my internet bills. This would encourage me to create many such softwares :)

| PayPal | <a href="https://www.paypal.com/paypalme/ganeshkavhar" target="_blank"><img src="https://www.paypalobjects.com/webstatic/mktg/logo/AM_mc_vs_dc_ae.jpg" alt="Donate via PayPal!" title="Donate via PayPal!" /></a> |
|:-------------------------------------------:|:-------------------------------------------------------------:|
| ₹ (INR)  | <a href="https://www.instamojo.com/@ganeshkavhar/" target="_blank"><img src="https://www.soldermall.com/images/pic-online-payment.jpg" alt="Donate via Instamojo" title="Donate via instamojo" /></a> |
